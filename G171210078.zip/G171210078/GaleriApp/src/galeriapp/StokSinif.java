/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class StokSinif {
    int arac_id,galeri_id,stok_id,stok_degeri;

    public StokSinif(int arac_id, int galeri_id, int stok_id, int stok_degeri) {
        this.arac_id = arac_id;
        this.galeri_id = galeri_id;
        this.stok_id = stok_id;
        this.stok_degeri = stok_degeri;
    }
    
}
