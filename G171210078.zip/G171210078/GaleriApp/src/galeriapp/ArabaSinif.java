/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class ArabaSinif {

    

    

    public ArabaSinif(int arac_ID, int yakit_ID, int marka_ID, int kasa_ID, int vites_ID, int fiyat, String aciklama, String marka_adi, String vites_tipi, String kasa_tipi, String yakit_tipi) {
        this.arac_ID = arac_ID;
        this.yakit_ID = yakit_ID;
        this.marka_ID = marka_ID;
        this.kasa_ID = kasa_ID;
        this.vites_ID = vites_ID;
        this.fiyat = fiyat;
        this.aciklama = aciklama;
        this.marka_adi = marka_adi;
        this.vites_tipi = vites_tipi;
        this.kasa_tipi = kasa_tipi;
        this.yakit_tipi = yakit_tipi;
    }
    
    
    int arac_ID, yakit_ID, marka_ID, kasa_ID, vites_ID, fiyat;
    String aciklama;
    String marka_adi,vites_tipi,kasa_tipi,yakit_tipi;

    
    

    
    
    
}
