/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class MotorsikletSinif {
    int arac_id;
    String aciklama;
    int fiyat;
    int galeri_id;
    int marka_id;
    int vites_id;

    public MotorsikletSinif(int arac_id, String aciklama, int fiyat, int galeri_id, int marka_id, int vites_id) {
        this.arac_id = arac_id;
        this.aciklama = aciklama;
        this.fiyat = fiyat;
        this.galeri_id = galeri_id;
        this.marka_id = marka_id;
        this.vites_id = vites_id;
    }
    
    
    
}
