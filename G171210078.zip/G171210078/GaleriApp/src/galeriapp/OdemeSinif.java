/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class OdemeSinif {
    int musteri_id;
    int odeme_id;
    String odeme_tipi;

    public OdemeSinif(int musteri_id, int odeme_id, String odeme_tipi) {
        this.musteri_id = musteri_id;
        this.odeme_id = odeme_id;
        this.odeme_tipi = odeme_tipi;
    }
    
    
}
