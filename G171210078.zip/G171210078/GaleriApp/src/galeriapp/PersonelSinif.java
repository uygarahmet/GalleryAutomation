/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class PersonelSinif {
    String ad,soyad,email;
    int adres_id,galeri_id,personel_id;

    public PersonelSinif(String ad, String soyad, String email, int adres_id, int galeri_id, int personel_id) {
        this.ad = ad;
        this.soyad = soyad;
        this.email = email;
        this.adres_id = adres_id;
        this.galeri_id = galeri_id;
        this.personel_id = personel_id;
    }
    
    
}
