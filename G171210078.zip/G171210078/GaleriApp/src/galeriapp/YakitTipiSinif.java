/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class YakitTipiSinif {
    int yakittipi_id;
    String tipi;

    public YakitTipiSinif(int yakittipi_id, String tipi) {
        this.yakittipi_id = yakittipi_id;
        this.tipi = tipi;
    }
    
    
    
}
