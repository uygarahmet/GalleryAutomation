/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class MarkaSinif {
    int Marka_ID;
    String marka_adi,mensei;

    public MarkaSinif(int Marka_ID, String marka_adi, String mensei) {
        this.Marka_ID = Marka_ID;
        this.marka_adi = marka_adi;
        this.mensei = mensei;
    }
    
}
