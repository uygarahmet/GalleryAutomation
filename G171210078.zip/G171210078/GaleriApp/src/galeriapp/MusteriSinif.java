/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class MusteriSinif {
    int musteri_id;
    String ad;
    String soyad;
    int adres_id;
    String email;
    int galeri_id;

    public MusteriSinif(int musteri_id, String ad, String soyad, int adres_id, String email, int galeri_id) {
        this.musteri_id = musteri_id;
        this.ad = ad;
        this.soyad = soyad;
        this.adres_id = adres_id;
        this.email = email;
        this.galeri_id = galeri_id;
    }
    
}
