/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class VitesSinif {
    int vites_id;
    String tipi;

    public VitesSinif(int vites_id, String tipi) {
        this.vites_id = vites_id;
        this.tipi = tipi;
    }
    
    
    
}
