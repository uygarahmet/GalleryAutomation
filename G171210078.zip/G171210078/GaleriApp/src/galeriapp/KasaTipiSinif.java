/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class KasaTipiSinif {
    int kasatipi_id;
    String kasatipi;

    public KasaTipiSinif(int kasatipi_id, String kasatipi) {
        this.kasatipi_id = kasatipi_id;
        this.kasatipi = kasatipi;
    }
    
    
}
