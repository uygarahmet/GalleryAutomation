/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;

/**
 *
 * @author emin
 */
public class SatilikAraclar extends javax.swing.JFrame {

    /**
     * Creates new form SatilikAraclar
     */
    
    public SatilikAraclar() throws SQLException {
        jTextArea1 = new JTextArea();
        
        initComponents();
        jTextArea1.setEditable(false);
        jTextArea1.setBackground(Color.lightGray);
        Baglanti b = new Baglanti("araba_getir()");
       
        ResultSet rGecici = b.TabloGetir();
        ArabaSinif arabaGecici = null;
        ArrayList<ArabaSinif> arabaListe = new ArrayList<ArabaSinif>();
        while(rGecici.next())
        {
            arabaGecici = new ArabaSinif(
                    rGecici.getInt("arac_id"),
                    rGecici.getInt("yakit_id"),
                    rGecici.getInt("marka_id"),
                    rGecici.getInt("kasa_id"),
                    rGecici.getInt("vites_id"),
                    rGecici.getInt("fiyat"),
                    rGecici.getString("aciklama"),
                    "",
                    "",
                    "",
                    "");
            arabaListe.add(arabaGecici);
           
            
        }
        
        b = new Baglanti("marka");
        rGecici = b.TabloGetir();
        MarkaSinif markalar = null;
        
        ArrayList<MarkaSinif> markaListe = new ArrayList<MarkaSinif>();
       
        while(rGecici.next())
        {
            markalar = new MarkaSinif(rGecici.getInt("marka_ID"),rGecici.getString("markaadi"),rGecici.getString("mensei"));
            markaListe.add(markalar);
        }
        
        
        b = new Baglanti("yakittipi");
        rGecici = b.TabloGetir();
        YakitTipiSinif yakitlar = null;
        
        ArrayList<YakitTipiSinif> yakitTipiListe = new ArrayList<YakitTipiSinif>();
       
        while(rGecici.next())
        {
            yakitlar = new YakitTipiSinif(rGecici.getInt("yakittipi_id"),rGecici.getString("tipi"));
            yakitTipiListe.add(yakitlar);
        }
        
        b = new Baglanti("vites");
        rGecici = b.TabloGetir();
        VitesSinif vitesTipleri = null;
        
        ArrayList<VitesSinif> vitesTipleriListe = new ArrayList<VitesSinif>();
       
        while(rGecici.next())
        {
            vitesTipleri = new VitesSinif(rGecici.getInt("vites_id"),rGecici.getString("tipi"));
            vitesTipleriListe.add(vitesTipleri);
        }
        
        
        b = new Baglanti("kasatipi");
        rGecici = b.TabloGetir();
        KasaTipiSinif kasaTipleri = null;
        
        ArrayList<KasaTipiSinif> kasaTipleriListe = new ArrayList<KasaTipiSinif>();
       
        while(rGecici.next())
        {
            kasaTipleri = new KasaTipiSinif(rGecici.getInt("kasatipi_id"),rGecici.getString("tipi"));
            kasaTipleriListe.add(kasaTipleri);
        }
        
       
        
        for (int i = 0; i < arabaListe.size(); i++) 
        {
            for (int j = 0; j < markaListe.size(); j++) 
            {
                
                if(arabaListe.get(i).marka_ID == markaListe.get(j).Marka_ID)
                {
                    arabaListe.get(i).marka_adi = markaListe.get(j).marka_adi;
                }
                
            }
            for (int j = 0; j < yakitTipiListe.size(); j++) 
            {
                if(arabaListe.get(i).yakit_ID == yakitTipiListe.get(j).yakittipi_id)
                    arabaListe.get(i).yakit_tipi = yakitTipiListe.get(j).tipi;
                
            }
            
            for (int j = 0; j < vitesTipleriListe.size(); j++) 
            {
                if(arabaListe.get(i).vites_ID == vitesTipleriListe.get(j).vites_id)
                    arabaListe.get(i).vites_tipi = vitesTipleriListe.get(j).tipi;
                
            }
            
            for (int j = 0; j < kasaTipleriListe.size(); j++) 
            {
                if(arabaListe.get(i).kasa_ID == kasaTipleriListe.get(j).kasatipi_id)
                    arabaListe.get(i).kasa_tipi = kasaTipleriListe.get(j).kasatipi;
                
            }
            
            
            jTextArea1.append("Marka: " + arabaListe.get(i).marka_adi +
                    " --- Aciklama: " + arabaListe.get(i).aciklama +
                    " --- Vites: " + arabaListe.get(i).vites_tipi +
                    " --- Kasa Tipi: " + arabaListe.get(i).kasa_tipi +
                    " --- Yakit Tipi: " + arabaListe.get(i).yakit_tipi +
                    " --- Fiyat: " + arabaListe.get(i).fiyat +
                    
                    "\n");
            
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 806, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 505, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
        
         */
        
        
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new SatilikAraclar().setVisible(true);
                    
                } catch (SQLException ex) {
                    Logger.getLogger(SatilikAraclar.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
