/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

import java.sql.Date;

/**
 *
 * @author emin
 */
public class SatilmisAracSinif {
    int arac_id,musteri_id,personel_id,satilmis_id;
    Date tarih;

    public SatilmisAracSinif(int arac_id, int musteri_id, int personel_id, int satilmis_id, Date tarih) {
        this.arac_id = arac_id;
        this.musteri_id = musteri_id;
        this.personel_id = personel_id;
        this.satilmis_id = satilmis_id;
        this.tarih = tarih;
    }
    
    
}
