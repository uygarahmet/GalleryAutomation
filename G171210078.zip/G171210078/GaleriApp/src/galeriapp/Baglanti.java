/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author emin
 */
public class Baglanti 
{
    String tablo;
    public Baglanti(String tablo)
    {
        this.tablo = tablo;
    }

    public Baglanti() {
        
    }
    public void AracSat(String fonkAdi) throws SQLException
    {
        Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Galeri",
                    "postgres", "3646");
            
            String sorgu = "SELECT * FROM " + fonkAdi; 
            
            Statement stmt;
            stmt =  (Statement) conn.createStatement();
            
            ResultSet rs = (stmt).executeQuery(sorgu);
            
            conn.close();
    }
    public void TabloyaEkle(String fonkAdi) throws SQLException
    {
        Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Galeri",
                    "postgres", "3646");
            
            String sorgu = "SELECT * FROM " + fonkAdi; 
            
            Statement stmt;
            stmt =  (Statement) conn.createStatement();
            
            ResultSet rs = (stmt).executeQuery(sorgu);
            
            conn.close();
    }
    public ResultSet TabloGetir()
    {
        try
        {   /***** Bağlantı kurulumu *****/
            Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Galeri",
                    "postgres", "3646");
            
            String sorgu = "SELECT * FROM " + tablo; 
            
            Statement stmt;
            stmt =  (Statement) conn.createStatement();
            
            ResultSet rs = (stmt).executeQuery(sorgu);
            
            conn.close();
            return rs;

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("HxATA");
            return null;
        }
        
    }
    
        
    
}
