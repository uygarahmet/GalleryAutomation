/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeriapp;

/**
 *
 * @author emin
 */
public class AdresSinif {
    String adres;
    int adres_id;
    int sehir_id;
    String telefon;

    public AdresSinif(String adres, int adres_id, int sehir_id, String telefon) {
        this.adres = adres;
        this.adres_id = adres_id;
        this.sehir_id = sehir_id;
        this.telefon = telefon;
    }
    
    
    
    
}
