--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12rc1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Galeri; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Galeri" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE "Galeri" OWNER TO postgres;

\connect "Galeri"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: araba_ekle(integer, integer, character varying, character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.araba_ekle(aracid integer, galeriidp integer, yakittipip character varying, markap character varying, kasatipip character varying, vitesturu character varying, aciklamap character varying, fiyatp integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
begin
	insert into arac(arac_id,galeri_id)
	values(aracid,galeriidp);

	insert into araba(arac_id,galeri_id,yakit_id,marka_id,kasa_id, vites_id, aciklama,fiyat)
	values(aracid,galeriidp,(select yakittipi_id from yakittipi where tipi = yakitTipiP),(select marka_id from marka where markaadi = markaP),(select kasatipi_id from kasatipi where tipi = kasaTipiP),(select vites_id from vites where tipi = vitesTuru),aciklamap,fiyatp);
	if found then
		return 1;
	else return 0;
	end if;
end
$$;


ALTER FUNCTION public.araba_ekle(aracid integer, galeriidp integer, yakittipip character varying, markap character varying, kasatipip character varying, vitesturu character varying, aciklamap character varying, fiyatp integer) OWNER TO postgres;

--
-- Name: araba_getir(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.araba_getir() RETURNS TABLE(arac_id integer, galeri_id integer, yakit_id integer, marka_id integer, kasa_id integer, vites_id integer, aciklama character varying, fiyat integer)
    LANGUAGE plpgsql
    AS $$BEGIN
	return query
		select * from araba ;
END
$$;


ALTER FUNCTION public.araba_getir() OWNER TO postgres;

--
-- Name: araba_sat(integer, integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.araba_sat(aracid integer, satilmisid integer, musteriad character varying, personelad character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$begin
	DELETE FROM araba WHERE arac_id=aracid;
	insert into satilmisarac(satilmis_id,musteri_id,personel_id,arac_id,tarih)
	values(satilmisid,(select musteri_id from musteri where ad = musteriad),(select personel_id from personel where ad = personelad),aracid,'2019-01-01');

	
	if found then
		return 1;
	else return 0;
	end if;
end
$$;


ALTER FUNCTION public.araba_sat(aracid integer, satilmisid integer, musteriad character varying, personelad character varying) OWNER TO postgres;

--
-- Name: marka_getir(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.marka_getir() RETURNS TABLE(marka_id integer, markaadi character varying, mensei character varying)
    LANGUAGE plpgsql
    AS $$BEGIN
	return query
		select * from marka order by marka_id;
END
$$;


ALTER FUNCTION public.marka_getir() OWNER TO postgres;

--
-- Name: musteri_ekle(integer, integer, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.musteri_ekle(musteriidp integer, adresidp integer, adp character varying, soyadp character varying, emailp character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
begin
	
	insert into musteri(musteri_id,adres_id,galeri_id,ad,soyad,email)
	values(musteriidp,adresidp,1,adp,soyadp,emailp);

	
	if found then
		return 1;
	else return 0;
	end if;
end
$$;


ALTER FUNCTION public.musteri_ekle(musteriidp integer, adresidp integer, adp character varying, soyadp character varying, emailp character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adres (
    adres_id integer NOT NULL,
    sehir_id integer,
    adres character varying(200),
    telefon character varying(11)
);


ALTER TABLE public.adres OWNER TO postgres;

--
-- Name: arac; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.arac (
    arac_id integer NOT NULL,
    galeri_id integer
);


ALTER TABLE public.arac OWNER TO postgres;

--
-- Name: araba; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.araba (
    arac_id integer,
    yakit_id integer,
    marka_id integer,
    kasa_id integer,
    vites_id integer,
    aciklama character varying(200),
    fiyat integer
)
INHERITS (public.arac);


ALTER TABLE public.araba OWNER TO postgres;

--
-- Name: galeri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.galeri (
    galeri_id integer NOT NULL,
    adres_id integer
);


ALTER TABLE public.galeri OWNER TO postgres;

--
-- Name: kasatipi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kasatipi (
    kasatipi_id integer NOT NULL,
    tipi character varying(100)
);


ALTER TABLE public.kasatipi OWNER TO postgres;

--
-- Name: marka; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marka (
    marka_id integer NOT NULL,
    markaadi character varying(100),
    mensei character varying(100)
);


ALTER TABLE public.marka OWNER TO postgres;

--
-- Name: motorsiklet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.motorsiklet (
    arac_id integer,
    marka_id integer,
    vites_id integer,
    aciklama character varying(200),
    fiyat integer
)
INHERITS (public.arac);


ALTER TABLE public.motorsiklet OWNER TO postgres;

--
-- Name: musteri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.musteri (
    musteri_id integer NOT NULL,
    adres_id integer,
    galeri_id integer,
    ad character varying(100),
    soyad character varying(100),
    email character varying(100)
);


ALTER TABLE public.musteri OWNER TO postgres;

--
-- Name: odeme; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.odeme (
    odeme_id integer NOT NULL,
    musteri_id integer
);


ALTER TABLE public.odeme OWNER TO postgres;

--
-- Name: personel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personel (
    personel_id integer NOT NULL,
    adres_id integer,
    galeri_id integer,
    ad character varying(100),
    soyad character varying(100),
    email character varying(100)
);


ALTER TABLE public.personel OWNER TO postgres;

--
-- Name: satilmisarac; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.satilmisarac (
    satilmis_id integer NOT NULL,
    musteri_id integer,
    personel_id integer,
    arac_id integer,
    tarih date
);


ALTER TABLE public.satilmisarac OWNER TO postgres;

--
-- Name: sehir; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sehir (
    sehir_id integer NOT NULL,
    sehir character varying(100)
);


ALTER TABLE public.sehir OWNER TO postgres;

--
-- Name: stok; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stok (
    stok_id integer NOT NULL,
    arac_id integer,
    galeri_id integer,
    stok_degeri integer NOT NULL
);


ALTER TABLE public.stok OWNER TO postgres;

--
-- Name: vites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vites (
    vites_id integer NOT NULL,
    tipi character varying(100)
);


ALTER TABLE public.vites OWNER TO postgres;

--
-- Name: yakittipi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yakittipi (
    yakittipi_id integer NOT NULL,
    tipi character varying(100)
);


ALTER TABLE public.yakittipi OWNER TO postgres;

--
-- Data for Name: adres; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.adres (adres_id, sehir_id, adres, telefon) VALUES (1, 2, 'ERDEMLI', '3333333333');
INSERT INTO public.adres (adres_id, sehir_id, adres, telefon) VALUES (2, 1, 'TOROS', '33333333333');
INSERT INTO public.adres (adres_id, sehir_id, adres, telefon) VALUES (3, 1, 'SULEYMAN DEMIREL BULVARI SAKARYA APT.', '5555555555');


--
-- Data for Name: araba; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.araba (arac_id, galeri_id, yakit_id, marka_id, kasa_id, vites_id, aciklama, fiyat) VALUES (1, 1, 1, 2, 2, 2, 'TEMiz', 100000);
INSERT INTO public.araba (arac_id, galeri_id, yakit_id, marka_id, kasa_id, vites_id, aciklama, fiyat) VALUES (10, 1, 2, 1, 2, 2, 'asdadad', 10000);
INSERT INTO public.araba (arac_id, galeri_id, yakit_id, marka_id, kasa_id, vites_id, aciklama, fiyat) VALUES (7, 1, 1, 1, 2, 2, 'asdadad', 10000);
INSERT INTO public.araba (arac_id, galeri_id, yakit_id, marka_id, kasa_id, vites_id, aciklama, fiyat) VALUES (999, 1, 1, 4, 2, 2, 'asdadad', 10000);
INSERT INTO public.araba (arac_id, galeri_id, yakit_id, marka_id, kasa_id, vites_id, aciklama, fiyat) VALUES (2113, 1, 1, 4, 2, 2, 'asdadad', 10000);
INSERT INTO public.araba (arac_id, galeri_id, yakit_id, marka_id, kasa_id, vites_id, aciklama, fiyat) VALUES (34, 1, 1, 3, 1, 1, 'jTextField2', 1212);


--
-- Data for Name: arac; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.arac (arac_id, galeri_id) VALUES (1, 1);
INSERT INTO public.arac (arac_id, galeri_id) VALUES (2, 1);
INSERT INTO public.arac (arac_id, galeri_id) VALUES (10, 1);
INSERT INTO public.arac (arac_id, galeri_id) VALUES (7, 1);
INSERT INTO public.arac (arac_id, galeri_id) VALUES (999, 1);
INSERT INTO public.arac (arac_id, galeri_id) VALUES (2113, 1);
INSERT INTO public.arac (arac_id, galeri_id) VALUES (34, 1);


--
-- Data for Name: galeri; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.galeri (galeri_id, adres_id) VALUES (1, NULL);


--
-- Data for Name: kasatipi; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kasatipi (kasatipi_id, tipi) VALUES (1, 'hatchback');
INSERT INTO public.kasatipi (kasatipi_id, tipi) VALUES (2, 'sedan');
INSERT INTO public.kasatipi (kasatipi_id, tipi) VALUES (3, 'coupe');
INSERT INTO public.kasatipi (kasatipi_id, tipi) VALUES (4, 'station-wagon');


--
-- Data for Name: marka; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.marka (marka_id, markaadi, mensei) VALUES (1, 'BMW', 'ALMANYA');
INSERT INTO public.marka (marka_id, markaadi, mensei) VALUES (2, 'AUDI', 'ALMANYA');
INSERT INTO public.marka (marka_id, markaadi, mensei) VALUES (3, 'FIAT', 'ITALYA');
INSERT INTO public.marka (marka_id, markaadi, mensei) VALUES (4, 'ANADOL', 'TURKIYE');


--
-- Data for Name: motorsiklet; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: musteri; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.musteri (musteri_id, adres_id, galeri_id, ad, soyad, email) VALUES (1, 1, 1, 'Mert', 'MErt', 'asdaf@asd.ada');
INSERT INTO public.musteri (musteri_id, adres_id, galeri_id, ad, soyad, email) VALUES (45, 2, 1, 'Emin', 'Ozakalyci', 'asdasf@asd.adad');
INSERT INTO public.musteri (musteri_id, adres_id, galeri_id, ad, soyad, email) VALUES (3333, 1, 1, 'qwe', 'qwe', 'qweq');


--
-- Data for Name: odeme; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: personel; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.personel (personel_id, adres_id, galeri_id, ad, soyad, email) VALUES (1, 1, 1, 'Ahmet', 'MEhmet', 'asdasd@asda.sda');


--
-- Data for Name: satilmisarac; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.satilmisarac (satilmis_id, musteri_id, personel_id, arac_id, tarih) VALUES (2, 1, 1, 2, '2019-01-01');


--
-- Data for Name: sehir; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sehir (sehir_id, sehir) VALUES (1, 'ADANA');
INSERT INTO public.sehir (sehir_id, sehir) VALUES (2, 'MERSIN');
INSERT INTO public.sehir (sehir_id, sehir) VALUES (3, 'SAKARYA');


--
-- Data for Name: stok; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: vites; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.vites (vites_id, tipi) VALUES (1, 'manuel');
INSERT INTO public.vites (vites_id, tipi) VALUES (2, 'otomatik');


--
-- Data for Name: yakittipi; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.yakittipi (yakittipi_id, tipi) VALUES (1, 'benzin');
INSERT INTO public.yakittipi (yakittipi_id, tipi) VALUES (2, 'dizel');


--
-- Name: adres adres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT adres_pkey PRIMARY KEY (adres_id);


--
-- Name: araba araba_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.araba
    ADD CONSTRAINT araba_pkey PRIMARY KEY (arac_id);


--
-- Name: arac arac_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arac
    ADD CONSTRAINT arac_pkey PRIMARY KEY (arac_id);


--
-- Name: galeri galeri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.galeri
    ADD CONSTRAINT galeri_pkey PRIMARY KEY (galeri_id);


--
-- Name: kasatipi kasatipi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kasatipi
    ADD CONSTRAINT kasatipi_pkey PRIMARY KEY (kasatipi_id);


--
-- Name: marka marka_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marka
    ADD CONSTRAINT marka_pkey PRIMARY KEY (marka_id);


--
-- Name: motorsiklet motorsiklet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motorsiklet
    ADD CONSTRAINT motorsiklet_pkey PRIMARY KEY (arac_id);


--
-- Name: musteri musteri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri
    ADD CONSTRAINT musteri_pkey PRIMARY KEY (musteri_id);


--
-- Name: odeme odeme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odeme
    ADD CONSTRAINT odeme_pkey PRIMARY KEY (odeme_id);


--
-- Name: personel personel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT personel_pkey PRIMARY KEY (personel_id);


--
-- Name: satilmisarac satilmisarac_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.satilmisarac
    ADD CONSTRAINT satilmisarac_pkey PRIMARY KEY (satilmis_id);


--
-- Name: sehir sehir_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sehir
    ADD CONSTRAINT sehir_pkey PRIMARY KEY (sehir_id);


--
-- Name: stok stok_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok
    ADD CONSTRAINT stok_pkey PRIMARY KEY (stok_id);


--
-- Name: vites vites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vites
    ADD CONSTRAINT vites_pkey PRIMARY KEY (vites_id);


--
-- Name: yakittipi yakittipi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yakittipi
    ADD CONSTRAINT yakittipi_pkey PRIMARY KEY (yakittipi_id);


--
-- Name: adres adres_sehir_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT adres_sehir_id_fkey FOREIGN KEY (sehir_id) REFERENCES public.sehir(sehir_id);


--
-- Name: araba araba_arac_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.araba
    ADD CONSTRAINT araba_arac_id_fkey FOREIGN KEY (arac_id) REFERENCES public.arac(arac_id);


--
-- Name: araba araba_kasa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.araba
    ADD CONSTRAINT araba_kasa_id_fkey FOREIGN KEY (kasa_id) REFERENCES public.kasatipi(kasatipi_id);


--
-- Name: araba araba_marka_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.araba
    ADD CONSTRAINT araba_marka_id_fkey FOREIGN KEY (marka_id) REFERENCES public.marka(marka_id);


--
-- Name: araba araba_vites_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.araba
    ADD CONSTRAINT araba_vites_id_fkey FOREIGN KEY (vites_id) REFERENCES public.vites(vites_id);


--
-- Name: araba araba_yakit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.araba
    ADD CONSTRAINT araba_yakit_id_fkey FOREIGN KEY (yakit_id) REFERENCES public.yakittipi(yakittipi_id);


--
-- Name: arac arac_galeri_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arac
    ADD CONSTRAINT arac_galeri_id_fkey FOREIGN KEY (galeri_id) REFERENCES public.galeri(galeri_id);


--
-- Name: galeri galeri_adres_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.galeri
    ADD CONSTRAINT galeri_adres_id_fkey FOREIGN KEY (adres_id) REFERENCES public.adres(adres_id);


--
-- Name: motorsiklet motorsiklet_arac_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motorsiklet
    ADD CONSTRAINT motorsiklet_arac_id_fkey FOREIGN KEY (arac_id) REFERENCES public.arac(arac_id);


--
-- Name: motorsiklet motorsiklet_marka_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motorsiklet
    ADD CONSTRAINT motorsiklet_marka_id_fkey FOREIGN KEY (marka_id) REFERENCES public.marka(marka_id);


--
-- Name: motorsiklet motorsiklet_vites_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.motorsiklet
    ADD CONSTRAINT motorsiklet_vites_id_fkey FOREIGN KEY (vites_id) REFERENCES public.vites(vites_id);


--
-- Name: musteri musteri_adres_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri
    ADD CONSTRAINT musteri_adres_id_fkey FOREIGN KEY (adres_id) REFERENCES public.adres(adres_id);


--
-- Name: musteri musteri_galeri_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musteri
    ADD CONSTRAINT musteri_galeri_id_fkey FOREIGN KEY (galeri_id) REFERENCES public.galeri(galeri_id);


--
-- Name: odeme odeme_musteri_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odeme
    ADD CONSTRAINT odeme_musteri_id_fkey FOREIGN KEY (musteri_id) REFERENCES public.musteri(musteri_id);


--
-- Name: personel personel_adres_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT personel_adres_id_fkey FOREIGN KEY (adres_id) REFERENCES public.adres(adres_id);


--
-- Name: personel personel_galeri_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT personel_galeri_id_fkey FOREIGN KEY (galeri_id) REFERENCES public.galeri(galeri_id);


--
-- Name: satilmisarac satilmisarac_arac_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.satilmisarac
    ADD CONSTRAINT satilmisarac_arac_id_fkey FOREIGN KEY (arac_id) REFERENCES public.arac(arac_id);


--
-- Name: satilmisarac satilmisarac_musteri_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.satilmisarac
    ADD CONSTRAINT satilmisarac_musteri_id_fkey FOREIGN KEY (musteri_id) REFERENCES public.musteri(musteri_id);


--
-- Name: satilmisarac satilmisarac_personel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.satilmisarac
    ADD CONSTRAINT satilmisarac_personel_id_fkey FOREIGN KEY (personel_id) REFERENCES public.personel(personel_id);


--
-- Name: stok stok_arac_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok
    ADD CONSTRAINT stok_arac_id_fkey FOREIGN KEY (arac_id) REFERENCES public.arac(arac_id);


--
-- Name: stok stok_galeri_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stok
    ADD CONSTRAINT stok_galeri_id_fkey FOREIGN KEY (galeri_id) REFERENCES public.vites(vites_id);


--
-- PostgreSQL database dump complete
--

